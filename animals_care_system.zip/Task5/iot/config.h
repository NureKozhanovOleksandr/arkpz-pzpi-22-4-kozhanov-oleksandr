#ifndef CONFIG_H
#define CONFIG_H

// WiFi credentials
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Enter your ngrok URL
const char* baseURL = "/api/iot";

// Device credentials
const char* deviceSecret = "test-secret";

#endif